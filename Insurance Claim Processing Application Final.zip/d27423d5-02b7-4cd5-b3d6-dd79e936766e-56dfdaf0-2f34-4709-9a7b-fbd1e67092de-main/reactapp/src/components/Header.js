import React from 'react'

function Header() {
  return (
    <header>
        <h1>Insurance Claim Processing System</h1>
        <p>Use the menu above to manage customers and claims.</p>
    </header>
  )
}

export default Header

