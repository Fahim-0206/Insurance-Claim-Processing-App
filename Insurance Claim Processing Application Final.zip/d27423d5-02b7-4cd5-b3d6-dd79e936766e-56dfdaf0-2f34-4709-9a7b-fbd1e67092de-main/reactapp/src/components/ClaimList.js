import React, { useState, useEffect } from 'react';
import './ClaimList.css';
import { useNavigate } from 'react-router-dom';

const ClaimList = () => {
  const [claims, setClaims] = useState([]);
  const [status, setStatus] = useState('ALL');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClaims = async () => {
      try {
        const response = await fetch(`https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/claims?status=${status}`);
        if (response.ok) {
          const data = await response.json();
          setClaims(data);
        } else {
          setMessage('Error fetching claims');
        }
      } catch (error) {
        setMessage('Network error occurred');
      }
    };
    fetchClaims();
  }, [status]);

  const handleRowClick = (claimId) => navigate(`/claim-details/${claimId}`);

  return (
    <div className="form-container">
      <h2>All Claims</h2>
      <div className="filter-section">
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="ALL">ALL</option>
          <option value="PENDING">PENDING</option>
          <option value="APPROVED">APPROVED</option>
        </select>
        <button className="btn-primary" onClick={() => navigate('/submit-claim')}>Submit New Claim</button>
      </div>
      {message ? (
        <div className="error" data-testid="error-message">{message}</div>
      ) : claims.length === 0 ? (
        <p>No Claims Registered.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Claim ID</th>
              <th>Customer Name</th>
              <th>Claim Type</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Submission Date</th>
            </tr>
          </thead>
          <tbody>
            {claims.map(claim => (
              <tr key={claim.id} onClick={() => handleRowClick(claim.id)} style={{ cursor: 'pointer' }}>
                <td>{claim.id}</td>
                <td>{claim.customerName}</td>
                <td>{claim.claimType}</td>
                <td>{claim.claimAmount}</td>
                <td>{claim.status}</td>
                <td>{claim.submissionDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ClaimList;
