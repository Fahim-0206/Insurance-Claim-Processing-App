import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './ClaimDetail.css';
import CustomerDetail from './CustomerDetail';

const ClaimDetail = () => {
  const { id } = useParams();
  const [claim, setClaim] = useState(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClaim = async () => {
      try {
        const response = await fetch(`https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/claims/${id}`);
        if (response.ok) {
          const data = await response.json();
          setClaim(data);
        } else {
          setMessage('Error fetching claim details');
        }
      } catch (error) {
        setMessage('Network error occurred');
      }
    };
    fetchClaim();
  }, [id]);

  if (!claim) return <div className="form-container">No Claims Registered.</div>;

  return (
    <div className="form-container">
      <h2>Claim Details</h2>
      <p><strong>Claim ID:</strong> {claim.id}</p>
      <p><strong>Customer Name:</strong> {CustomerDetail.CustomerDetail}</p>
      <p><strong>Claim Type:</strong> {claim.claimType}</p>
      <p><strong>Amount:</strong> ₹{claim.claimAmount}</p>
      <p><strong>Status:</strong> {claim.status}</p>
      <p><strong>Submission Date:</strong> {claim.submissionDate}</p>
      <p><strong>Incident Date:</strong> {claim.incidentDate}</p>
      <p><strong>Description:</strong> {claim.description}</p>
      {message && <div className="error" data-testid="error-message">{message}</div>}
      <button className="btn-primary" onClick={() => navigate('/claims')}>Back to Claims</button>
    </div>
  );
};

export default ClaimDetail;
