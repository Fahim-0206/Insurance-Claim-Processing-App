import axios from 'axios';

const CustomerService = {
  fetchCustomers: async () => {
    try {
      const response = await axios.get('http://localhost:8081/api/customers');
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch customers');
    }
  },
  createCustomer: async (customer) => {
    try {
      const response = await axios.post('http://localhost:8081/api/customers', customer);
      return response.data;
    } catch (error) {
      throw new Error('Failed to create customer');
    }
  },
  updateCustomer: async (id, customer) => {
    try {
      const response = await axios.put(`http://localhost:8081/api/customers/${id}`, customer);
      return response.data;
    } catch (error) {
      throw new Error('Failed to update customer');
    }
  },
};

export default CustomerService;
