import React, { useState, useEffect } from 'react';
import './CustomerList.css';
import { useNavigate } from 'react-router-dom';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await fetch('https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/customers');
        if (response.ok) {
          const data = await response.json();
          setCustomers(data);
        } else {
          setMessage('Error fetching customers');
        }
      } catch (error) {
        setMessage('Network error occurred');
      }
    };
    fetchCustomers();
  }, []);

  const handleRowClick = (customerId) => navigate(`/customer-details/${customerId}`);

  return (
    <div className="form-container">
      <h2>All Customers</h2>
      {message ? (
        <div className="error" data-testid="error-message">{message}</div>
      ) : customers.length === 0 ? (
        <p>No Customer Registered.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Policy Number</th>
            </tr>
          </thead>
          <tbody>
            {customers.map(customer => (
              <tr key={customer.customerId} onClick={() => handleRowClick(customer.customerId)} style={{ cursor: 'pointer' }}>
                <td>{customer.customerId}</td>
                <td>{customer.name}</td>
                <td>{customer.email}</td>
                <td>{customer.phoneNumber}</td>
                <td>{customer.policyNumber}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <button className="btn-primary" onClick={() => navigate('/new-customer')}>Register New Customer</button>
    </div>
  );
};

export default CustomerList;
