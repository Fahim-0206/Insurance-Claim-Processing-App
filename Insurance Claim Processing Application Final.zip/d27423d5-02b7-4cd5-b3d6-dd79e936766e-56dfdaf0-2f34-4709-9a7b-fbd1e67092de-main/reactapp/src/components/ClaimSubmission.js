import React, { useState, useEffect } from 'react';
import './ClaimSubmission.css';
import { useNavigate } from 'react-router-dom';

const ClaimSubmission = () => {
  const [formData, setFormData] = useState({ customerId: '', claimType: 'Health', claimAmount: '', incidentDate: '', description: '' });
  const [customers, setCustomers] = useState([]);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await fetch('https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/customers');
        if (response.ok) {
          const data = await response.json();
          setCustomers(data);
        } else {
          setMessage('Error fetching customers');
        }
      } catch (error) {
        setMessage('Network error occurred');
      }
    };
    fetchCustomers();
  }, []);

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.customerId || !formData.claimType || !formData.claimAmount || !formData.incidentDate || !formData.description) {
      setMessage('All fields are required');
      return;
    }
    if (parseFloat(formData.claimAmount) <= 0) {
      setMessage('Claim amount must be positive');
      return;
    }
    try {
      const response = await fetch('https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/claims', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        setMessage('Claim submitted successfully');
        setFormData({ customerId: '', claimType: 'Health', claimAmount: '', incidentDate: '', description: '' });
      } else {
        setMessage('Error submitting claim');
      }
    } catch (error) {
      setMessage('Network error occurred');
    }
  };

  return (
    <div className="form-container">
      <h2>Submit New Claim</h2>
      <form onSubmit={handleSubmit}>
        <select name="customerId" value={formData.customerId} onChange={handleChange}>
          <option value="">Select customer</option>
          {customers.map(customer => (
            <option key={customer.customerId} value={customer.customerId}>{customer.name}</option>
          ))}
        </select>
        <select name="claimType" value={formData.claimType} onChange={handleChange}>
          <option value="Health">Health</option>
          <option value="Auto">Auto</option>
        </select>
        <input
          name="claimAmount"
          type="number"
          value={formData.claimAmount}
          onChange={handleChange}
          placeholder="Claim Amount"
        />
        <input
          name="incidentDate"
          type="date"
          value={formData.incidentDate}
          onChange={handleChange}
        />
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Description"
        />
        <button type="submit" className="btn-primary">Submit Claim</button>
      </form>
      {message && <div className="error" data-testid="error-message">{message}</div>}
    </div>
  );
};

export default ClaimSubmission;
