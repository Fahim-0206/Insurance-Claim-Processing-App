import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './CustomerDetail.css';

const CustomerDetail = () => {
  const { id } = useParams();
  const [customer, setCustomer] = useState(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCustomer = async () => {
      try {
        const response = await fetch(`https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/customers/${id}`);
        if (response.ok) {
          const data = await response.json();
          setCustomer(data);
        } else {
          setMessage('Error fetching customer details');
        }
      } catch (error) {
        setMessage('Network error occurred');
      }
    };
    fetchCustomer();
  }, [id]);

  if (!customer) return <div className="form-container">No Customer Registered.</div>;

  return (
    <div className="form-container">
      <h2>Customer Details</h2>
      <p><strong>ID:</strong> {customer.customerId}</p>
      <p><strong>Name:</strong> {customer.name}</p>
      <p><strong>Email:</strong> {customer.email}</p>
      <p><strong>Phone Number:</strong> {customer.phoneNumber}</p>
      <p><strong>Policy Number:</strong> {customer.policyNumber}</p>
      {message && <div className="error" data-testid="error-message">{message}</div>}
      <button className="btn-primary" onClick={() => navigate('/customers')}>Back to Customers</button>
    </div>
  );
};

export default CustomerDetail;
