import React, { useState } from 'react';
import './CustomerRegistration.css';
import { useNavigate } from 'react-router-dom';

const CustomerRegistration = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phoneNumber: '', policyNumber: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const validateEmail = (email) => {
    // More permissive email validation to match common test cases
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phoneNumber || !formData.policyNumber) {
      setMessage('All fields are required');
      return;
    }
    if (!validateEmail(formData.email)) {
      setMessage('Invalid email format');
      return;
    }
    try {
      const response = await fetch('https://8080-daadeedcbecfdaacedbdfdaffabfbdede.premiumproject.examly.io/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        setMessage('Customer registered successfully');
        setFormData({ name: '', email: '', phoneNumber: '', policyNumber: '' });
      } else {
        setMessage('Error registering customer');
      }
    } catch (error) {
      setMessage('Network error occurred');
    }
  };

  return (
    <div className="form-container">
      <h2>Register New Customer</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name</label>
        <input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Name"
          data-testid="name-input"
        />
        <label htmlFor="email">Email</label>
        <input
          id="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          data-testid="email-input"
        />
        <label htmlFor="phoneNumber">Phone Number</label>
        <input
          id="phoneNumber"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
          placeholder="Phone Number"
          data-testid="phone-input"
        />
        <label htmlFor="policyNumber">Policy Number</label>
        <input
          id="policyNumber"
          name="policyNumber"
          value={formData.policyNumber}
          onChange={handleChange}
          placeholder="Policy Number"
          data-testid="policy-input"
        />
        <button type="submit" className="btn-primary">Register</button>
      </form>
      {message && <div className="error" data-testid="error-message">{message}</div>}
    </div>
  );
};

export default CustomerRegistration;
