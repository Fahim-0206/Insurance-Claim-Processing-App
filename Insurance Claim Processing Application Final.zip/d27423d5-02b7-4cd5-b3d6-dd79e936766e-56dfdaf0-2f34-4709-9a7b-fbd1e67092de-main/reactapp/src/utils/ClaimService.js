import axios from 'axios';

const ClaimService = {
  fetchClaims: async (status) => {
    try {
      const response = await axios.get(`http://localhost:8081/api/claims?status=${status || 'ALL'}`);
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch claims');
    }
  },
  createClaim: async (claim) => {
    try {
      const response = await axios.post('http://localhost:8081/api/claims', claim);
      return response.data;
    } catch (error) {
      throw new Error('Failed to create claim');
    }
  },
  updateClaim: async (id, claim) => {
    try {
      const response = await axios.put(`http://localhost:8081/api/claims/${id}`, claim);
      return response.data;
    } catch (error) {
      throw new Error('Failed to update claim');
    }
  },
};

export default ClaimService;
