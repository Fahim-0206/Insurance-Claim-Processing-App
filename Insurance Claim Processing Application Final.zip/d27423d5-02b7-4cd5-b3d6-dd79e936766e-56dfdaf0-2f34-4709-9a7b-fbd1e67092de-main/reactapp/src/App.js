// src/App.js (Updated with Header, Footer, and enhanced Navbar)
import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes ,useNavigate } from 'react-router-dom';
import CustomerRegistration from './components/CustomerRegistration';
import ClaimSubmission from './components/ClaimSubmission';
import ClaimList from './components/ClaimList';
import CustomerList from './components/CustomerList';
import ClaimDetail from './components/ClaimDetail';
import CustomerDetail from './components/CustomerDetail';
import './App.css'; // Import updated global CSS

const Home=()=> {
  const navigate=useNavigate();
  return(
  <div className="home-container">
    <h2>Insurance Claim Processing System</h2>
    <p>Use the menu above to manage customers and claims.</p>
    <button className="btn-primary" onClick={() => navigate('/new-customer')}>Register New Customer</button>
  </div>
  );
};

const App = () => (
  <Router>
    <header className="app-header">
      <div className="header-content">
        <h1>InsureApp</h1>
        <p>Your Trusted Insurance Claim Manager</p>
      </div>
    </header>
    <nav className="main-nav">
      <div className="nav-container">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/customers" className="nav-link">Customers</Link>
        <Link to="/new-customer" className="nav-link">New Customer</Link>
        <Link to="/claims" className="nav-link">Claims</Link>
        <Link to="/submit-claim" className="nav-link">Submit Claim</Link>
      </div>
    </nav>
    <main className="app-content">
      <Routes>
        <Route path="/new-customer" element={<CustomerRegistration />} />
        <Route path="/submit-claim" element={<ClaimSubmission />} />
        <Route path="/claims" element={<ClaimList />} />
        <Route path="/" element={
          <Home/>
        } />
        <Route path="/claim-details/:id" element={<ClaimDetail />} />
        <Route path="/customers" element={<CustomerList />} />
        <Route path="/customer-details/:id" element={<CustomerDetail />} />
      </Routes>
    </main>
    <footer className="app-footer">
      <p>&copy; 2025 InsureEase. All rights reserved.</p>
    </footer>
  </Router>
);

export default App;
